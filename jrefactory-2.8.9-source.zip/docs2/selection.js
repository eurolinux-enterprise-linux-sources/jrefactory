
     var oldElem;
     var oldSubElem;
     
     function setSelected(id) {
       var elem;
       if (oldElem) {
          oldElem.className="nav_option";
       }
       if (document.all) {
          elem = document.all(id);
       } else if (document.getElementById) {
          elem = document.getElementById(id);
       }
       if (elem) {
          elem.className="nav_option_selected";
          oldElem = elem;
       }
       return true;
     }
     function setSubSelected(id) {
       var elem;
       if (oldSubElem) {
          oldSubElem.className="nav_suboption";
       }
       if (document.all) {
          elem = document.all(id);
       } else if (document.getElementById) {
          elem = document.getElementById(id);
       }
       if (elem) {
          elem.className="nav_suboption_selected";
          oldSubElem = elem;
       }
       return true;
     }

