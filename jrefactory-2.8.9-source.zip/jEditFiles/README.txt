TO Run JavaStyle in jEdit
-------------------------

Unzip the jar files contained in JavaStyle-2.8.03.zip into either the .jedit/jars directory
or the jEdit 4.2pre5/jars directory.



To Compile JavaStyle
--------------------


Unzip the jar files contained in JavaStyle-2.8.03-source.zip into the directory
JavaStyle-2.8.03.zip was unzipped into.

There should also be ErrorList.jar and ProjectViewer.jar in that directory.

Load the build.xml file into AntFarm (or equivalent) and run the target "jEdit.JavaStyle.jar"

The resulting Jar file will be created in ant.build/lib

